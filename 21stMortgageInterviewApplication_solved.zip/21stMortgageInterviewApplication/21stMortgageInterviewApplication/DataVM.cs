﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Input;

namespace _21stMortgageInterviewApplication
{
    public class DataVM : BaseViewModel
    {
        public ICommand LargestValueCommand
        {
            get;
            set;
        }

        public ICommand SumEvenCommand
        {
            get;
            set;
        }
        public ICommand SumOddCommand
        {
            get;
            set;
        }

        private string _name;
        private string _result;
        private bool? _isGreeColor;

        private List<double> values;
        public bool? IsGreeColor
        {
            get
            {
                return _isGreeColor;
            }
            set
            {
                _isGreeColor = value;
                OnPropertyChanged();
            }
        }
        public string Result
        {
            get
            {
                return _result;
            }
            set
            {
                _result = value;
                OnPropertyChanged();
            }
        }
        public string Name
        {
            get
            {
                return _name;
            }
            set
            {
                _name = value;
            }
        }

        public DataVM()
        {
            values = new List<double>();
            LargestValueCommand = new RelayCommand(ExecuteLargestValueMethod, CanExecuteMyMethod);
            SumEvenCommand = new RelayCommand(ExecuteSumEvenMethod, CanExecuteMyMethod);
            SumOddCommand = new RelayCommand(ExecuteSumOddMethod, CanExecuteMyMethod);
        }


        private bool CanExecuteMyMethod(object parameter)
        {
            if (string.IsNullOrEmpty(Name))
            {
                IsGreeColor = null;
                Result = null;
                return false;
            }
            else
            {
                if (Name != "")
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        private void ExecuteLargestValueMethod(object parameter)
        {

            populateValues();
            if (values != null && values.Count > 0)
            {
                var res = values.Max();
                IsGreeColor = res > 0;
                Result = res.ToString();
            }
            else
            {
                Result = string.Empty;
            }

        }
        private void ExecuteSumEvenMethod(object parameter)
        {
            populateValues();
            if (values != null && values.Count > 0)
            {
                var res = values.Where(x => x % 2 == 0)?.Sum();
                IsGreeColor = res > 0;
                Result = res.ToString();
            }
            else
            {
                Result = string.Empty;
            }
        }
        private void ExecuteSumOddMethod(object parameter)
        {
            populateValues();
            if (values != null && values.Count > 0)
            {
                var res = values.Where(x => x % 2 != 0)?.Sum();
                IsGreeColor = res > 0;
                Result = res.ToString();
            }
            else
            {
                Result = string.Empty;
            }
        }
        private void populateValues()
        {
            values = new List<double>();
            double val = 0;
            var _strvalues = Name.Split(',', StringSplitOptions.RemoveEmptyEntries);
            foreach (var value in _strvalues)
            {
                double.TryParse(value.Trim(), out val);
                values.Add(val);
            }

        }

    }
}
